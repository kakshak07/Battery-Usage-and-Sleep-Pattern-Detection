# -*- coding: utf-8 -*-
"""
Created on Thu Jul 30 09:28:33 2020

@author: dell
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline
